-- Create the STOCK table:
create table stock
 (stocksymbol char(3) primary key,
  stockname  char(20),
  currentprice number(6,2));
-- Insert rows:
insert into stock values ('JFM','Jetform',21.75);
insert into stock values ('JDS','JDS Fitel',20.55);
insert into stock values ('NTL','NorTel',54.10);
insert into stock values ('COS','Corel',3.16);
insert into stock values ('MLT','Mitel Corp.',14.30);
insert into stock values ('CSN','Cognos',27.50);
insert into stock values ('RIM','Research in Motion',90.95);



create table test_table(
             age  number,
             full_name varchar2(64));
      insert into test_table values(
             21,'John Smith');
      insert into test_table values(
             22,'Mary Smith');

insert into test_table values( 21,'John Smith');
insert into test_table values( 22,'Mary Smith');

CREATE TABLE books
(
 title VARCHAR2(60),
 author VARCHAR2(60),
 isbn NUMBER(10,0) 
      CONSTRAINT pk_books PRIMARY KEY,
 pub_date DATE DEFAULT SYSDATE
);



CREATE TABLE book_reviews
(
 isbn NUMBER(10,0) 
      CONSTRAINT fk_books_booksrev REFERENCES books(isbn), 
 reviewer VARCHAR2(30),
 comments VARCHAR2(150)
);




INSERT INTO books VALUES
('The Importance of Being Earnest','Oscar Wilde',  -- this is a comment
 9876543210,'14-FEB-1895');



INSERT INTO book_reviews VALUES
(9876543210,'Alice','Excellent work, humorous and witty.');


CREATE SEQUENCE book_seq;

SELECT book_seq.NEXTVAL FROM DUAL;  -- displays the next value 

SELECT book_seq.CURRVAL FROM DUAL;  -- shows the current value 



INSERT INTO books VALUES
('Oliver Twist','Charles Dickens',book_seq.NEXTVAL,'12-SEP-1839');


